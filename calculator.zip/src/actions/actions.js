"use strict";

export const DISPLAY = 'DISPLAY';
export const EVALUATE = 'EVALUATE';
