"use strict";

import React from 'react';

const FinalResult = (props) => {
  return <h3>{props.inputExpression}</h3>;
}

export default FinalResult;